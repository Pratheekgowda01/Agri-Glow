'use client'

import { useState } from 'react'
import { CreditCard, BanknoteIcon as Bank, Smartphone, Wallet, Truck } from 'lucide-react'

export default function PaymentOptions() {
  const [selectedPayment, setSelectedPayment] = useState('')
  const [showAddressForm, setShowAddressForm] = useState(false)

  const paymentMethods = [
    { id: 'card', name: 'Credit/Debit Card', icon: CreditCard },
    { id: 'netbanking', name: 'Net Banking', icon: Bank },
    { id: 'upi', name: 'UPI', icon: Smartphone },
    { id: 'wallet', name: 'Wallet', icon: Wallet },
    { id: 'cod', name: 'Cash on Delivery', icon: Truck },
  ]

  const handlePaymentSelection = (paymentId: string) => {
    setSelectedPayment(paymentId)
    setShowAddressForm(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden md:max-w-2xl">
        <div className="p-8">
          <h1 className="text-3xl font-bold text-center text-green-800 mb-8">Select Payment Method</h1>
          <div className="space-y-4">
            {paymentMethods.map((method) => (
              <label
                key={method.id}
                className={`flex items-center p-4 rounded-lg transition-all duration-300 ease-in-out cursor-pointer ${
                  selectedPayment === method.id
                    ? 'bg-green-100 border-2 border-green-500'
                    : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                }`}
              >
                <input
                  type="radio"
                  name="payment"
                  value={method.id}
                  checked={selectedPayment === method.id}
                  onChange={() => handlePaymentSelection(method.id)}
                  className="sr-only"
                />
                <method.icon className={`w-6 h-6 mr-3 ${selectedPayment === method.id ? 'text-green-600' : 'text-gray-400'}`} />
                <span className={`text-lg ${selectedPayment === method.id ? 'text-green-800 font-semibold' : 'text-gray-700'}`}>
                  {method.name}
                </span>
              </label>
            ))}
          </div>

          {selectedPayment && (
            <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow-inner transition-all duration-300 ease-in-out">
              <h2 className="text-2xl font-semibold text-green-800 mb-4">
                {paymentMethods.find((m) => m.id === selectedPayment)?.name} Details
              </h2>
              {selectedPayment === 'card' && <CardDetails />}
              {selectedPayment === 'netbanking' && <NetBankingDetails />}
              {selectedPayment === 'upi' && <UPIDetails />}
              {selectedPayment === 'wallet' && <WalletDetails />}
              {selectedPayment === 'cod' && <CODDetails />}
            </div>
          )}

          {showAddressForm && <AddressForm />}
        </div>
      </div>
    </div>
  )
}

function CardDetails() {
  return (
    <div className="space-y-4">
      <input type="text" placeholder="Card Number" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      <input type="text" placeholder="Name on Card" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      <div className="flex space-x-4">
        <input type="text" placeholder="Expiry Date (MM/YY)" className="w-1/2 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
        <input type="text" placeholder="CVV" className="w-1/2 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      </div>
      <button className="w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 transition duration-300 ease-in-out">Pay Now</button>
    </div>
  )
}

function NetBankingDetails() {
  return (
    <div className="space-y-4">
      <input type="text" placeholder="Bank Name" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      <input type="text" placeholder="Account Number" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      <input type="text" placeholder="IFSC Code" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      <button className="w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 transition duration-300 ease-in-out">Pay Now</button>
    </div>
  )
}

function UPIDetails() {
  return (
    <div className="space-y-4">
      <input type="text" placeholder="UPI ID" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      <button className="w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 transition duration-300 ease-in-out">Pay Now</button>
    </div>
  )
}

function WalletDetails() {
  return (
    <div className="space-y-4">
      <input type="text" placeholder="Wallet Provider" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      <input type="text" placeholder="Wallet ID" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
      <button className="w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 transition duration-300 ease-in-out">Pay Now</button>
    </div>
  )
}

function CODDetails() {
  return (
    <div className="space-y-4">
      <p className="text-gray-600">Payment will be collected upon delivery.</p>
      <button className="w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 transition duration-300 ease-in-out">Confirm Order</button>
    </div>
  )
}

function AddressForm() {
  return (
    <div className="mt-8 p-6 bg-gray-50 rounded-lg shadow-inner transition-all duration-300 ease-in-out">
      <h2 className="text-2xl font-semibold text-green-800 mb-4">Enter Shipping Address</h2>
      <div className="space-y-4">
        <input type="text" placeholder="Full Name" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
        <input type="text" placeholder="Street Address" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
        <input type="text" placeholder="City" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
        <input type="text" placeholder="State" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
        <input type="text" placeholder="Postal Code" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
        <input type="text" placeholder="Country" className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent" />
        <button className="w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 transition duration-300 ease-in-out">Confirm Address</button>
      </div>
    </div>
  )
}

