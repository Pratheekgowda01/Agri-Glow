// Function to generate and display the invoice
function printInvoice() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    let totalPrice = 0;
    let invoiceDetails = '<ul>';

    // Get user details from localStorage (assuming they are saved during checkout)
    const userDetails = JSON.parse(localStorage.getItem('orderDetails')) || {};

    // Add user details to the invoice
    let userInfo = `
        <h3>User Details:</h3>
        <p><strong>Name:</strong> ${userDetails.fullName}</p>
        <p><strong>Phone Number:</strong> ${userDetails.phoneNumber}</p>
        <p><strong>Address:</strong> ${userDetails.streetAddress}, ${userDetails.city}, ${userDetails.state}, ${userDetails.postalCode}, ${userDetails.country}</p>
        <p><strong>Address Type:</strong> ${userDetails.addressType}</p>
    `;

    // Loop through the cart items and prepare the invoice details
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        invoiceDetails += `
            <li>
                <strong>${item.name}</strong><br>
                Price: Rs ${item.price}<br>
                Quantity: ${item.quantity}<br>
                Total: Rs ${itemTotal}
            </li>
        `;
        totalPrice += itemTotal;
    });

    invoiceDetails += '</ul>';

    // Update the invoice section with the user details and cart items
    document.getElementById('invoice-user-details').innerHTML = userInfo; // Assuming you have an element with this ID for user info
    document.getElementById('invoice-details').innerHTML = invoiceDetails;
    document.getElementById('invoice-total-price').textContent = ` Total Price : ${totalPrice}`;
    
    // Show the invoice section
    document.getElementById('invoice-section').style.display = 'block';
}
