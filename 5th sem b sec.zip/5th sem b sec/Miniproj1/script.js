function addToCart(productName, productPrice, quantity) {
  // Product images for each product
  const productImages = {
    'UREA': 'download.jpeg',
    'Magnesium Sulphate': 'mgso4.jpeg',
    'NPK': 'npk.jpeg',
    // Add more products and their respective image URLs here
  };

  // Get existing cart from localStorage (or create a new one)
  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  // Check if the product already exists in the cart
  let productIndex = cart.findIndex(item => item.name === productName);

  if (productIndex !== -1) {
      // If product is already in cart, update the quantity
      cart[productIndex].quantity += parseInt(quantity);
  } else {
      // Otherwise, add a new product to the cart with the image
      cart.push({
          name: productName,
          price: productPrice,
          quantity: parseInt(quantity),
          image: productImages[productName]  // Assign the image URL to the product
      });
  }

  // Save the updated cart to localStorage
  localStorage.setItem('cart', JSON.stringify(cart));

  alert(`${productName} added to cart.`);
}
