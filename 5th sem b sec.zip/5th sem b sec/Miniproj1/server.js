const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const crypto = require('crypto');  // For generating random OTPs

const app = express();
app.use(bodyParser.json());

// Nodemailer Transporter Setup
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'agriglow8@gmail.com',   // Replace with your Gmail address
    pass: 'Agriglow@2024',    // Replace with your Gmail password or App Password
  }
});

// Route to send OTP
app.post('/send-otp', (req, res) => {
  const { email } = req.body;

  // Generate a random 6-digit OTP
  const otp = crypto.randomInt(100000, 999999);

  // Send OTP to the user's Gmail
  const mailOptions = {
    from: 'agriglow8@gmail.com',  // Replace with your Gmail address
    to: email,
    subject: 'Your OTP for Password Reset',
    text: `Your OTP for password reset is: ${otp}`,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return res.status(500).send('Error sending email.');
    } else {
      console.log('Email sent: ' + info.response);
      // Store OTP temporarily (In real-world, use a DB to store the OTP for a limited time)
      res.status(200).send({ message: 'OTP sent successfully!' });
    }
  });
});

// Route to verify OTP and reset password
app.post('/verify-otp', (req, res) => {
  const { email, otp, newPassword } = req.body;

  // In real-world, you would verify OTP here
  // If OTP matches, reset the password
  if (otp === 'stored-otp') {  // You would compare it with the stored OTP from your DB or memory
    // Reset password process
    // In a real-world app, update the password in the database
    res.status(200).send('Password reset successful!');
  } else {
    res.status(400).send('Invalid OTP!');
  }
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
