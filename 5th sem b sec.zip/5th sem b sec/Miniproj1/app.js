const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());

// Create a reusable transporter object using SMTP transport
const transporter = nodemailer.createTransport({
    service: 'gmail', // Use your email service or configure SMTP server
    auth: {
        user: 'your-email@gmail.com',
        pass: 'your-email-password' // Or use an environment variable
    }
});

// Route to send OTP
app.post('/send-otp', (req, res) => {
    const { email } = req.body;

    // Generate OTP
    const otp = crypto.randomInt(100000, 999999);  // Generate a 6-digit OTP
    const otpExpiry = Date.now() + 15 * 60 * 1000; // OTP valid for 15 minutes

    // Store OTP and expiry (use a database or in-memory storage)
    // For demo, we store in memory, in production you would store in DB
    global.otpData = { email, otp, otpExpiry };

    // Send OTP email
    const mailOptions = {
        from: 'your-email@gmail.com',
        to: email,
        subject: 'Your OTP for Forgot Password',
        text: `Your OTP is: ${otp}. It will expire in 15 minutes.`
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
            return res.status(500).send({ success: false, message: 'Failed to send OTP' });
        }
        res.status(200).send({ success: true, message: 'OTP sent successfully' });
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
