// Function to add products to the cart
function addToCart(name, price, quantity) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Check if the product already exists in the cart
    const existingProduct = cart.find(item => item.name === name);
    
    if (existingProduct) {
        existingProduct.quantity += parseInt(quantity); // If exists, increase quantity
    } else {
        // If not in the cart, add a new product
        cart.push({ name, price, quantity: parseInt(quantity) });
    }
    
    // Save the updated cart back to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Show a confirmation message
    alert(`Added ${quantity} of ${name} to the cart at Rs ${price * quantity}`);
}

// Function to display cart contents (optional, for viewing cart page)
function displayCart() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartList = document.getElementById('cart-items');
    
    cartList.innerHTML = ''; // Clear existing cart items

    if (cart.length === 0) {
        cartList.innerHTML = '<p>Your cart is empty.</p>';
        return;
    }

    // Loop through the cart and display each product
    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');

        const nameElement = document.createElement('h3');
        nameElement.textContent = item.name;

        const priceElement = document.createElement('p');
        priceElement.textContent = `Rs: ${item.price}`;

        const quantityElement = document.createElement('p');
        quantityElement.textContent = `Quantity: ${item.quantity}`;

        cartItem.appendChild(nameElement);
        cartItem.appendChild(priceElement);
        cartItem.appendChild(quantityElement);
        
        cartList.appendChild(cartItem);
    });
}
