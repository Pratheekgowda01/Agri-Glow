document.querySelector('form').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent the form from submitting normally

    // Get values from the form
    const name = document.querySelector('input[name="name"]').value;
    const category = document.querySelector('select[name="product"]').value;  // Should be 'vegetables' for this case
    const price = document.querySelector('input[name="price"]').value;
    const quantity = document.querySelector('input[name="quantity"]').value;
    const description = document.querySelector('textarea[name="description"]').value;
    const image = document.querySelector('input[name="image"]').files[0]; // Image file

    // Create a FileReader to read the image as base64
    const reader = new FileReader();
    reader.onload = function (event) {
        const product = {
            name,
            category,
            price,
            quantity,
            description,
            imageURL: event.target.result, // Base64 image data
        };

        // Retrieve existing products for the selected category
        let products = JSON.parse(localStorage.getItem(category)) || [];
        products.push(product); // Add new product to the list

        // Save updated products in localStorage under the category
        localStorage.setItem(category, JSON.stringify(products));

        // Optionally, redirect to the buy page or show a success message
        alert('Product added successfully!');
        window.location.href = 'buy.html'; // Redirect after submission
    };
    reader.readAsDataURL(image); // Read the image file
});
